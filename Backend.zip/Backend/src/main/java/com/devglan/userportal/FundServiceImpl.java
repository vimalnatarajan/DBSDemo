package com.devglan.userportal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class FundServiceImpl implements FundService {

	@Autowired
	private FundRepository repository;
	
	@Override
	public List<User> findAllOrderBy() {
		
		List<User> topUser = repository.findAllOrderBy(orderByIdAsc());
		
		return topUser.subList(0, 5);
	}

	private Sort orderByIdAsc() {
	   // return new Sort(Sort.Direction.ASC, "id")
	     //            .and(new Sort(Sort.Direction.ASC, "lastName"));
		return new Sort(Sort.Direction.DESC, "lastName");
	}
	
	
	
}
