package com.devglan.userportal;

import java.util.List;

public interface FundService {
	
	List<User> findAllOrderBy();

}
