package com.devglan.userportal;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.repository.Repository;

public interface FundRepository extends Repository<User, Integer> {
	
	List<User> findAllOrderBy(Sort sort);

}
