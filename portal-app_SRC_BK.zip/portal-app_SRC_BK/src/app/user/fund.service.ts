import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { User } from '../models/user.model';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  
  @Injectable()
  export class FundService {


    constructor(private http:HttpClient) {}

    private userUrl = 'http://localhost:8080/funds';
    //private userUrl = '/api';
  
    public getUsers() {
      return this.http.get<User[]>(this.userUrl);
    }

  }