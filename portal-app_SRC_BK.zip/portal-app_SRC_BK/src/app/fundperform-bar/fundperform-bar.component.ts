import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../models/user.model';
import { FundService } from '../user/fund.service';

@Component({
  selector: 'app-fundperform-bar',
  templateUrl: './fundperform-bar.component.html',
  styleUrls: ['./fundperform-bar.component.css']
})
export class FundperformBarComponent implements OnInit {
  users: User[];

  constructor(private router: Router, private fundService: FundService) {}

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  };
  public barChartLabels:string[] = [];
  public barChartType = 'bar';
  public barChartLegend = true;
  public chartdata:number[]=[];
  public barChartData=[
   {data: [], label: ''}];
   public barChartTitle= "Last Year Fund Performance Chart";
 
  
  ngOnInit() {
    this.fundService.getUsers()
    .subscribe( respdata => {
      respdata.forEach(item => {
        this.barChartLabels.push(item.firstName);
        this.chartdata.push(Number(item.lastName));
      })
     this.barChartData = [{data:this.chartdata,label:'FundPerfromance'}];
     this.barChartLegend
    });

  }
}
 
