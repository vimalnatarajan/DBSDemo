import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundperformBarComponent } from './fundperform-bar.component';

describe('FundperformBarComponent', () => {
  let component: FundperformBarComponent;
  let fixture: ComponentFixture<FundperformBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundperformBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundperformBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
