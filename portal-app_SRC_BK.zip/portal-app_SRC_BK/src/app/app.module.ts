import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { FundComponent } from './user/fund.component';
import { AppRoutingModule } from './app.routing.module';
import { Routes, RouterModule } from '@angular/router';
import {UserService} from './user/user.service';
import {FundService} from './user/fund.service';
import {HttpClientModule} from "@angular/common/http";
import {AddUserComponent} from './user/add-user.component';
import { FundperformBarComponent } from './fundperform-bar/fundperform-bar.component';

const routes: Routes = [
  {path: 'bar-chart', component: FundperformBarComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    FundComponent,
    AddUserComponent,
    FundperformBarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule,
    ChartsModule
  ],
  providers: [UserService, FundService],
  bootstrap: [AppComponent]
})
export class AppModule { }
